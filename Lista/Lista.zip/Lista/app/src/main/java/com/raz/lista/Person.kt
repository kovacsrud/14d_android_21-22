package com.raz.lista

data class Person(
    var vezeteknev:String,
    var keresztnev:String,
    var szuletesiEv:Int
)
